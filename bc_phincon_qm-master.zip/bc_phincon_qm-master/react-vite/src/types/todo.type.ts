export interface TodoType {
    id: string;
    text: string;
    completed: boolean;
}
