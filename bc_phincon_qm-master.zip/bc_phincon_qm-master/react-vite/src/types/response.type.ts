/* eslint-disable @typescript-eslint/no-explicit-any */
export interface ResponseType {
    data: any;
    message: string;
    success: boolean;
}
